module.exports = {
  entry: {
    googleMaps: ['./js/googleMaps.js']
  },
  output: {
    filename: 'dist/[name].min.js'
  }
}
