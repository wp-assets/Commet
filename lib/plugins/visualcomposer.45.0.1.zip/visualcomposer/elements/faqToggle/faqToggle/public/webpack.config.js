module.exports = {
  entry: {
    faqToggle: ['./js/faqToggle.js']
  },
  output: {
    filename: '[name].min.js'
  }
}
